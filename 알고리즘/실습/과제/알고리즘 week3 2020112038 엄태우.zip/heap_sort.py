#컴퓨터공학과 2020112038 엄태우
def make_heap(arr, root, last_node):
    parent = root
    root_value = arr[root]
    left_son = 2 * parent + 1
    right_son = left_son + 1
    while(left_son <= last_node):       #left_son이 존재할 경우 진행
        if(right_son <= last_node and arr[left_son] < arr[right_son]):  
                    #두 자식노드 중 더 작은 값을 son으로 지정
            son = right_son
        else:
            son = left_son
        if(root_value < arr[son]):          #부모 노드의 값이가 자식 노드의 값보다 작을 경우
            arr[parent] = arr[son]          #두 노드를 교환
            parent = son
            left_son = parent * 2 + 1
            right_son = left_son + 1
        else:
            break
    arr[parent] = root_value
    print(arr, root)
    return arr

def heap_sort(arr, n):
    for i in range(n//2, -1, -1):
        arr = make_heap(arr, i, n-1)        #배열의 원소들을 힙의 구조로 변환

    print("힙 생성 : ", arr)
    for i in range(n - 1, 0, -1):           
        arr[0], arr[i] = arr[i], arr[0]     #최댓값을 arr[i]와 교환한 뒤
        arr = make_heap(arr, 0, i - 1)      #최댓값을 제외한 남은 원소들을 재정비
    return arr

arr = [4, 1, 3, 2, 16, 9, 10, 14, 8, 7]
print("초기 : ", arr)
print("정렬 : ", heap_sort(arr, len(arr)))