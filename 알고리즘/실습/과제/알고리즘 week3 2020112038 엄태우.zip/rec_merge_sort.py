#컴퓨터공학과 2020112038 엄태우
def merge(arr, left, mid, right):
    leftptr = left
    rightptr = mid + 1
    bufptr = left
    buffer = [0 for _ in range(10)]   #사용할 버퍼 내부의 값을 0으로 초기화
    while (leftptr <= mid and rightptr <= right):  #왼쪽 포인터가 중간에 도착하거나 오른쪽 포인터가 오른쪽 배열의 끝에 도달할때까지
        if(arr[leftptr] < arr[rightptr]):       #왼쪽 배열과 오른쪽 배열중 더 작은 값을 버퍼로 전달
            buffer[bufptr] = arr[leftptr]
            bufptr += 1                     #전달한 후 버퍼의 포인터와 옮긴 배열의 포인터를 1씩 증가
            leftptr += 1
        else:
            buffer[bufptr] = arr[rightptr]
            bufptr += 1
            rightptr += 1
    if (leftptr > mid):                     #왼쪽 배열에서 남은 값이 있다면
        for i in range(rightptr, right + 1):    #버퍼에 뒤쪽에 이어서 저장
            buffer[bufptr] = arr[i]
            bufptr += 1
    else:
        for i in range(leftptr, mid + 1):
            buffer[bufptr] = arr[i]
            bufptr += 1
    print(arr, left, right, buffer)
    for i in range(left, right + 1):        #버퍼의 값을 본래 배열에 저장
        arr[i] = buffer[i]
    return arr

def rec_merge_sort(arr, left, right):
    if(left < right):               #원소가 두개 이상일 시에
        mid = (left + right)//2     #mid를 배열의 중간으로 지정
        rec_merge_sort(arr, left, mid)  #왼쪽 배열을 정렬
        rec_merge_sort(arr, mid + 1, right)     #오른쪽 배열을 정렬
        arr = merge(arr, left, mid, right)      #두 배열을 합병
    return arr

arr = [30, 20, 40, 35, 5, 50, 45, 10, 25, 15]
print(rec_merge_sort(arr, 0, 9))