#2020112038 컴퓨터공학과 엄태우
class Node():
    def __init__(self, data):
        self.data = data
        self.parent = self.left = self.right = None
        self.color = 'Red' #신규 삽입되는 노드는 항상 빨강
        

#레드블랙트리 key, 부모, 색상 출력
def print_rbt(node, n):
    if n == 1:
        print('--------------RedBlackTree---------------left')
    if not node.left  == None: 
        print_rbt(node.left, n+1)
    if node.parent != None:
        print('\t' * n, node.data, node.color)
    else:
        print("ROOT\t",node.data, node.color)
    if not node.right == None: 
        print_rbt(node.right, n+1)
    if n == 1:
        print('-----------------------------------------right')

class RedBlackTree:
    #조부모 노드 찾기
    def find_grand_node(self,node):
        if node != None and node.parent != None:
            return node.parent.parent
        else:
            return None
    
    #삼촌 노드 찾기
    def find_uncle_node(self,node):
        grand_node = self.find_grand_node(node)
        if grand_node == None:
            return None
    
        if node.parent == grand_node.left:  #반대쪽 자식 즉 삼촌 노드 반환
            return grand_node.right
        else:
            return grand_node.left
        
    #루트 노드는 항상 블랙  
    def root_is_black(self,node):
        if node.parent == None:
            node.color = 'Black'
            print("Root노드의 색을 Black으로 변경")
            print_rbt(self.root, 1)
        else:
            while node.parent.color == 'Red':
                self.insert_case1(node)     
    
    #case1. 부모노드, 삼촌노드 모두 빨강이라면 색변환 수행, 아닐경우 case2로 이동
    def insert_case1(self,node):
        uncle = self.find_uncle_node(node)
    
        if uncle != None and uncle.color == 'Red':
            node.parent.color = 'Black'
            uncle.color = 'Black'
            grand = self.find_grand_node(node)
            grand.color = 'Red'
            print("case1", node.data, "노드의 부모노드, 조부모노드, 삼촌노드 색 변경")
            print_rbt(self.root, 1)
            self.root_is_black(grand)
        else:       #삼촌노드가 Black이면 case3수행
            self.insert_case2(node)
    
    
    #case2.  삼촌노드가 Black이거나 None이면 rotate수행
    def insert_case2(self,node):
        grand = self.find_grand_node(node)
        if node == node.parent.right and node.parent == grand.left:
            print("case2 수행 시작")
            node = node.parent
            self.left_rotate(node)
        elif node == node.parent.left and node.parent == grand.right:
            print("case2 수행 시작")
            node = node.parent
            self.right_rotate(node)
        print("case3 수행 시작")            #case3. 부모노드와 조부모노드 색 변경 후 rotate수행
        node.parent.color = 'Black'
        grand.color = 'Red'
        print("{}노드를 Black으로 {}노드를 Red로".format(node.parent.data, grand.data))
        print_rbt(self.root, 1)

        if node == node.parent.left:    #타겟노드가 부모노드의 left_child일 경우
            self.right_rotate(grand)    #right_rotate 수행
        else:
            self.left_rotate(grand)

    def left_rotate(self,node):
        print(node.data,"노드를 기준으로 left_rotate()수행 전")
        print_rbt(self.root, 1)
        c = node.right
        p = node.parent
    
        if c.left != None:
            c.left.parent = node    #타겟노드의 right_child(c)의 left_child의 부모를 node로 설정
    
        node.right = c.left
        node.parent = c
        c.left = node       #타겟노드의 right_child(c)였던 노드의 left_child로 타겟노드를 연결
        c.parent = p        #타겟노드의 right_child였던 노드의 부모를 타겟노드의 부모였던 노드로 설정
        
        if c.parent == None:
            self.root = c
    
        if p != None:
            if p.left == node:
                p.left = c
            else:
                p.right = c
        print("left_rotate()수행 후")
        print_rbt(self.root, 1)

    def right_rotate(self,node):
        print(node.data, "노드를 기준으로 right_rotate()수행 전")
        print_rbt(self.root, 1)
        c = node.left
        p = node.parent
    
        if c.right != None:
            c.right.parent = node   #타겟노드의 left_child(c)의 right_child의 부모를 node로 설정
    
        node.left = c.right
        node.parent = c
        c.right = node      #타겟노드의 left_child(c)였던 노드의 left_child로 타겟노드를 연결
        c.parent = p        #타겟노드의 left_child였던 노드의 부모를 타겟노드의 부모였던 노드로 설정
        
        if c.parent == None:
            self.root = c
            
        if p != None:
            if p.right == node:
                p.right = c
            else:
                p.left = c
        print("right_rotate() 수행 후")
        print_rbt(self.root, 1)
            
    def __init__(self):
        self.root = None
        self.inserted_node = None
	
    #삽입
    def insert(self, data):
        self.root = self.insert_value(self.root, data, None)    #삽입 노드의 부모노드를 None으로 설정해 insert
        print(data,"삽입 완료")
        print_rbt(self.root, 1)
        self.root_is_black(self.inserted_node)
        return 
    
    def insert_value(self, node, data, parent_node):
        if node is None:
            node = Node(data)
            node.parent = parent_node
            self.inserted_node = node
        else:
            if data <= node.data:       #값 비교 후
                node.left = self.insert_value(node.left,data,node)      #더 작으면 왼쪽으로
            else:
                node.right = self.insert_value(node.right,data,node)    #더 크면 오른쪽으로
        return node
    
    #탐색
    def find(self,search_key):
        return self.find_value(self.root, search_key)
    
    def find_value(self, root, search_key):
        if root is None or root.data == search_key:
            return root 
        elif search_key > root.data:
            return self.find_value(root.right, search_key)
        else:
            return self.find_value(root.left, search_key)

rbt = RedBlackTree()

a = [20, 15, 14, 12, 13, 1]
    
for x in a:
    rbt.insert(x)

print_rbt(rbt.root, 1)