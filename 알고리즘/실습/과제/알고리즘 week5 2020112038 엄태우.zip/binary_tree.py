#컴퓨터공학과 2020112038 엄태우
class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

class binary_tree:
    def __init__(self, head):
        self.head = head        #루트 노드

    def insert(self, value):
        curr_node = self.head
        while True:
            if (value == curr_node.value):
                break
            if (value < curr_node.value):    #value가 더 작으면
                if (curr_node.left != None):  #왼쪽 자식 노드가 비어있지 않다면
                    curr_node = curr_node.left  #왼쪽 노드로 이동
                else:
                    curr_node.left = Node(value)  #왼쪽 자식 노드가 비어있으면 생성 후 연결
                    break
            else:           #value가 더 크다면
                if (curr_node.right != None):  #오른쪽 자식 노드가 비어있지 않다면
                    curr_node = curr_node.right  #오른쪽 자식 노드로 이동
                else:
                    curr_node.right = Node(value)  #오른쪽 자식 노드가 비어있으면 생성 후 연결 
                    break

    def search(self, value):
        curr_node = self.head
        while (curr_node):             #node가 none이 될때까지 반복
            if (curr_node.value == value):     #값을 찾으면
                if(curr_node.left):
                    print("left node:",curr_node.left.value, end=' ')
                if(curr_node.right):
                    print("right node:",curr_node.right.value)
                return True       #해당 노드를 반환
            elif (value < curr_node.value):        #찾으려는 값이 더 작을 경우
                curr_node = curr_node.left    #왼쪽으로 이동
            else:
                curr_node = curr_node.right   #클 경우는 오른쪽으로 이동
        return False            #찾지 못하고 while문이 끝나게 되면 못 찾았으므로 False반환
    
    def delete(self, value):
        self.head, ret = self.delete_sub(self.head, value)
        return ret

    def delete_sub(self, node, value):
        if(node == None):
            return node, False
        deleted = False
        if (node.value == value):      #삭제할 value를 찾았다면
            deleted = str(value) + " deleted"
            if (node.left and node.right): #왼쪽 자식과 오른쪽 자식이 모두 있을 경우
                parent, child = node, node.right
                while (child.left is not None):     #value가 있는 노드의 오른쪽 자식 중 가장 작은 노드(=child)를 찾기 위한 반복문
                    parent, child = child, child.left
                child.left = node.left     #삭제할 노드의 왼쪽 서브 트리를 child의 왼쪽 서브트리로 연결
                if (parent != node):       #child의 부모 노드가 삭제하려는 노드가 아닐경우
                    parent.left = child.right
                    child.right = node.right
                node = child
        elif (value < node.value):
            node.left, deleted = self.delete_sub(node.left, value)  #삭제하려는 값이 현재 노드보다 작을 경우 left자식 노드를 재귀
        else:
            node.right, deleted = self.delete_sub(node.right, value)    #삭제하려는 값이 현재 노드보다 작을 경우 right자식 노드를 재귀
        return node, deleted

arr = [6,2,4,16,10,8,12,14,9]

head = Node(20)
bst = binary_tree(head)

for i in arr:
    bst.insert(i)

print(bst.search(10))
print(bst.delete(6))
print(bst.search(10))