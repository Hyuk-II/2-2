#2020112038 엄태우

#brute-force 막대 자르기
def brute_cut_rod(p, n):
    max_price = p[n]    #현재 막대의 길이를 최대 가격으로 초기화
    for i in range(1, n):   
        max_price = max(max_price, p[i] + brute_cut_rod(p, n - i))
        #현재 최대 가격과 i길이로 자른 막대 가격 + 남은 막대 최대 가격 중 높은값을 선택
    return max_price

#동적 프로그래밍 막대 자르기
def dynamic_cut_rod(p, n):
    result_price = [0]      #결과 가격 리스트
    max_price = 0           
    for i in range(1, n + 1):
        for j in range(i):      #현재 길이까지 자를수 있는 모든 경우의 수만큼 반복
            max_price = max(max_price, p[i - j] + result_price[j])
                #현재 최대가격과 i-j길이로 자른 막대 가격 + 나머지 막대가격 중 높은 값을 선택
        result_price.append(max_price)
    return result_price[n]

list_p = [0,1,5,8,9,10,17,17,20,24,30]
print("brute-force result:", brute_cut_rod(list_p, 10))
print("dynamic result:", dynamic_cut_rod(list_p, 10))
