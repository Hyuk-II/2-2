#2020112038 컴퓨터공학과 엄태우
def brute_force_search(text, pattern):
    text_n = len(text)
    pattern_n = len(pattern)

    for i in range(text_n - pattern_n + 1):
        j = 0
        while j < pattern_n and text[i + j] == pattern[j]:
            j += 1
        if j == pattern_n:
            print("패턴이 {}번째부터 나타남".format(i))

def rabin_karp_search(text, pattern):
    text_n = len(text)
    pattern_n = len(pattern)
    d = 256  #문자 집합의 크기
    div_n = 101  #소수 선택 (해싱 함수를 사용할 때 나누는 수)

    #해시 값을 초기화
    p_hash = 0  #패턴의 해시 값
    t_hash = 0  #텍스트의 해시 값
    h = 1
    for i in range(pattern_n-1):
        h = (h * d) % div_n

    #초기 해시 값을 계산
    for i in range(pattern_n):
        p_hash = (d * p_hash + ord(pattern[i])) % div_n
        t_hash = (d * t_hash + ord(text[i])) % div_n

    #패턴을 텍스트 문자열 위로 이동하면서 비교
    for i in range(text_n - pattern_n + 1):
        #해시 값이 일치하는 경우에만 문자열 비교
        if p_hash == t_hash:
            match = True
            for j in range(pattern_n):
                if text[i + j] != pattern[j]:
                    match = False
                    break
            if match:
                print("패턴이 {}번째부터 나타남".format(i))
        #다음 해시 값을 계산
        if i < text_n - pattern_n:
            t_hash = (d * (t_hash - ord(text[i]) * h) + ord(text[i + pattern_n])) % div_n
            if t_hash < 0:
                t_hash += div_n

    return -1  #패턴이 발견되지 않은 경우 -1을 반환

def compute_prefix_function(pattern):
    m = len(pattern)
    pre_list = [0] * m    #접두사와 접미사의 최대 일치 길이를 저장할 리스트
    k = 0
    for i in range(1, m):
        while k > 0 and pattern[k] != pattern[i]:
            k = pre_list[k - 1]
        if pattern[k] == pattern[i]:
            k += 1
        pre_list[i] = k
    return pre_list

def kmp_search(text, pattern):
    text_n = len(text)
    pattern_n = len(pattern)
    pre_list = compute_prefix_function(pattern)   #패턴의 접두사와 접미사의 최대 일치 길이를 계산
    match_n = 0   #패턴 내에서 일치한 문자의 개수
    for i in range(text_n):
        #일치하지 않는 문자를 만날 때까지 패턴 내에서 이동
        while match_n > 0 and pattern[match_n] != text[i]:
            match_n = pre_list[match_n - 1]
        #문자가 일치하는 경우
        if pattern[match_n] == text[i]:
            match_n += 1
        #패턴이 전체 일치한 경우
        if match_n == pattern_n:
            print("패턴이 {}번째부터 나타남".format(i - pattern_n + 1))  #패턴이 발견된 위치를 출력
            match_n = pre_list[match_n - 1]  #다음 패턴을 찾기 위해 match_n을 이동

#2020112038 컴퓨터공학과 엄태우
#text = "ababcabcabababd"
#pattern = "ababd"
text = input("text: ")
pattern = input("pattern: ")
#brute_force_search(text, pattern)
#rabin_karp_search(text, pattern)
kmp_search(text, pattern)