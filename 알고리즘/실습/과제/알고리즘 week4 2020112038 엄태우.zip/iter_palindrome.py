#2020112038 엄태우

def iter_palindrome(text):
    n = len(text)
    for i in range(n // 2):     #중간까지 인덱스 지정
        if(text[i] != text[n - i - 1]):     #현재위치에 대칭되는 문자 비교
            return text + " is not Palindrome"
    return text + " is Palindrome"

f = open("example.txt", "r")
for i in f:
    print(iter_palindrome(i.strip()))
f.close()