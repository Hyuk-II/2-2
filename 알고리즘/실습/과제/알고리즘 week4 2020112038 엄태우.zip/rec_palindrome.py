#2020112038 엄태우

def rec_palindrome(file):
    if(len(file) == 0):
        return 
    text = file[0].strip()
    n = len(text)
    for i in range(n // 2):     #중간까지 인덱스 지정
        if(text[i] != text[n - i - 1]):     #현재위치에 대칭되는 문자 비교
            print(text + " is not Palindrome")
            return rec_palindrome(file[1:])     #다음 요소부터 마지막 요소까지의 리스트로 재귀함수 호출
    print(text + " is Palindrome")
    return rec_palindrome(file[1:])

f = open("example.txt", "r")
line = f.readlines()
rec_palindrome(line)
f.close()