#2020112038 엄태우
def counting_sort(arr):
    num = [0 for _ in range(10)]       #10개의 공간을 가진 N배열을 0으로 초기화
    for i in arr:
        num[i] += 1                    #키의 출현횟수 지정
    print("키의 출현 횟수\t\t",num)
    count = num[0]
    for i in range(len(num)):
        count += num[i]                 #누적 키의 출현 횟수 지정
        num[i] = count
    print("키의 누적 출현 횟수\t  N :",num)
    b = [0 for _ in range(len(arr))]     #arr과 같은 크기의 배열 B 0으로 초기화
    for i in arr:
        b[num[i] - 1] = i               #num배열에서 해당 원소가 위치해야 할값을 찾아 B배열에 저장
        num[i] -= 1                     #넣은 원소값의 위치 -1
        print("키의 누적 출현 횟수\t N :",num)
        print("배열\t\t\t B : ",b)
    return b

arr = [7, 5, 4, 6, 3, 6, 5, 4, 6, 7, 8, 9, 9, 3]
print("정렬 전\t\t\t",arr)
print("정렬 후\t\t\t",counting_sort(arr))